import os
import json
from google.cloud import bigquery

# --- CONFIGURATION ---
PROJECT_ID = "avid-willow-485619-g6"
DATASET_ID = "healthcare_agent_db"
TABLE_ID = "patient_telemetry"

def load_telemetry_to_bq():
    client = bigquery.Client(project=PROJECT_ID)
    
    # Create Dataset
    dataset_ref = f"{PROJECT_ID}.{DATASET_ID}"
    dataset = bigquery.Dataset(dataset_ref)
    dataset.location = "US"
    try:
        client.create_dataset(dataset)
        print(f"Created dataset {DATASET_ID}")
    except Exception:
        print(f"Dataset {DATASET_ID} already exists.")

    # Define Schema
    schema = [
        bigquery.SchemaField("patient_id", "STRING"),
        bigquery.SchemaField("timestamp", "TIMESTAMP"),
        bigquery.SchemaField("blood_pressure", "STRING"),
        bigquery.SchemaField("systolic_bp", "INTEGER"),
        bigquery.SchemaField("diastolic_bp", "INTEGER"),
        bigquery.SchemaField("spo2_percent", "INTEGER"),
        bigquery.SchemaField("blood_glucose_mg_dl", "INTEGER"),
        bigquery.SchemaField("weight_lbs", "INTEGER"),
    ]
    
    table_ref = f"{dataset_ref}.{TABLE_ID}"
    table = bigquery.Table(table_ref, schema=schema)
    try:
        client.create_table(table)
        print(f"Created table {TABLE_ID}")
    except Exception:
        print(f"Table {TABLE_ID} already exists.")

    # Load local JSON data into BigQuery
    rows_to_insert = []
    source_dir = "data/telemetry_structured"
    for filename in os.listdir(source_dir):
        if filename.endswith(".json"):
            with open(os.path.join(source_dir, filename), "r") as f:
                data = json.load(f)
                for record in data:
                    rows_to_insert.append({
                        "patient_id": record["patient_id"],
                        "timestamp": record["timestamp"],
                        "blood_pressure": record["sensor_readings"]["blood_pressure"],
                        "systolic_bp": record["sensor_readings"]["systolic_bp"],
                        "diastolic_bp": record["sensor_readings"]["diastolic_bp"],
                        "spo2_percent": record["sensor_readings"]["spo2_percent"],
                        "blood_glucose_mg_dl": record["sensor_readings"]["blood_glucose_mg_dl"],
                        "weight_lbs": record["sensor_readings"]["weight_lbs"]
                    })
    
    # Insert Data
    if rows_to_insert:
        errors = client.insert_rows_json(table_ref, rows_to_insert)
        if not errors:
            print(f"Successfully loaded {len(rows_to_insert)} records into BigQuery.")
        else:
            print(f"Errors inserting rows: {errors}")

if __name__ == "__main__":
    load_telemetry_to_bq()
