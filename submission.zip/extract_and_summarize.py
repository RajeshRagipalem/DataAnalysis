import json
from google import genai
from google.genai import types
from google.cloud import storage, bigquery

# --- CONFIGURATION ---
PROJECT_ID = "avid-willow-485619-g6"
LOCATION = "us-central1"
BUCKET_NAME = f"healthcare-agent-data-{PROJECT_ID}"
DATASET_ID = "healthcare_agent_db"
TABLE_ID = "patient_emr_baselines"
MODEL_ID = "gemini-2.5-flash"

def process_emr_to_bq():
    print(f"Initializing Clients...")
    ai_client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)
    storage_client = storage.Client(project=PROJECT_ID)
    bq_client = bigquery.Client(project=PROJECT_ID)
    
    # 1. Create the BigQuery Table for EMR Summaries
    dataset_ref = f"{PROJECT_ID}.{DATASET_ID}"
    table_ref = f"{dataset_ref}.{TABLE_ID}"
    
    schema = [
        bigquery.SchemaField("patient_id", "STRING"),
        bigquery.SchemaField("summary", "STRING"),
        bigquery.SchemaField("extracted_entities", "STRING") # Storing the JSON as a string for easy retrieval
    ]
    
    table = bigquery.Table(table_ref, schema=schema)
    try:
        bq_client.create_table(table)
        print(f"Created table {TABLE_ID}")
    except Exception:
        print(f"Table {TABLE_ID} already exists.")

    # 2. Process GCS Files and Load to BigQuery
    bucket = storage_client.bucket(BUCKET_NAME)
    blobs = bucket.list_blobs(prefix="emr_unstructured/")
    
    prompt = """
    You are a clinical data extraction agent. 
    Analyze the following patient EMR document and extract the information into a strict JSON format.
    
    The JSON must contain two main keys:
    1. "extracted_entities": A dictionary containing Patient ID, Name, Age, Condition, Medication, and Baseline Vitals.
    2. "summary": A concise, 2-sentence summary of the patient's current status and the medical plan.
    """
    
    rows_to_insert = []
    
    for blob in blobs:
        if not blob.name.endswith('.txt'):
            continue
            
        gcs_uri = f"gs://{BUCKET_NAME}/{blob.name}"
        print(f"\n--- Extracting {blob.name} ---")
        
        try:
            response = ai_client.models.generate_content(
                model=MODEL_ID,
                contents=[types.Part.from_uri(file_uri=gcs_uri, mime_type="text/plain"), prompt],
                config=types.GenerateContentConfig(response_mime_type="application/json")
            )
            
            parsed_json = json.loads(response.text)
            patient_id = parsed_json["extracted_entities"].get("Patient ID", "UNKNOWN")
            
            # Prepare the row for BigQuery
            rows_to_insert.append({
                "patient_id": patient_id,
                "summary": parsed_json["summary"],
                "extracted_entities": json.dumps(parsed_json["extracted_entities"])
            })
            print(f"Successfully processed {patient_id}")
            
        except Exception as e:
            print(f"Error processing {blob.name}: {e}")

    # 3. Insert into BigQuery
    if rows_to_insert:
        errors = bq_client.insert_rows_json(table_ref, rows_to_insert)
        if not errors:
            print(f"\n✅ Successfully loaded {len(rows_to_insert)} EMR baselines into BigQuery.")
        else:
            print(f"\n❌ Errors inserting rows: {errors}")

if __name__ == "__main__":
    process_emr_to_bq()
