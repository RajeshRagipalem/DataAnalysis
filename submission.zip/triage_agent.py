import json
from google import genai
from google.genai import types
from google.cloud import storage

# --- CONFIGURATION ---
PROJECT_ID = "avid-willow-485619-g6"
LOCATION = "us-central1"
BUCKET_NAME = f"healthcare-agent-data-{PROJECT_ID}"
MODEL_ID = "gemini-2.5-flash"

# Initialize clients
client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)
storage_client = storage.Client(project=PROJECT_ID)
bucket = storage_client.bucket(BUCKET_NAME)

# --- AGENT TOOLS (Modular Functions) ---

def tool_get_clinical_baseline(patient_id: str) -> str:
    """Tool: Reads the raw unstructured EMR file directly from GCS."""
    blob_path = f"emr_unstructured/{patient_id}_emr.txt"
    blob = bucket.blob(blob_path)
    if blob.exists():
        return blob.download_as_text()
    return f"Error: EMR for patient {patient_id} not found."

def tool_get_remote_telemetry(patient_id: str) -> list:
    """Tool: Reads the JSON stream from the home telemetry devices."""
    blob_path = f"telemetry_structured/{patient_id}_telemetry.json"
    blob = bucket.blob(blob_path)
    if blob.exists():
        return json.loads(blob.download_as_text())
    return []

def tool_clinical_knowledge_rag() -> str:
    """Tool: Simulates a RAG lookup returning valid institutional triage guidelines."""
    guidelines = """
    STANDARD CLINICAL MEDICAL REFERENCE LIMITS:
    - Normal Blood Pressure: Systolic < 120 AND Diastolic < 80 mmHg. 
    - Hypertensive Crisis Stage 2: Systolic >= 140 OR Diastolic >= 90 mmHg. Urgent evaluation required.
    - Normal Oxygen Saturation (SpO2): 95% - 100%.
    - Hypoxemia Danger Zone (COPD Baseline Dependent): SpO2 < 92% requires immediate supplemental oxygen or triage intervention.
    - Glucose Levels (Fasting): 70 - 130 mg/dL is normal. > 180 mg/dL indicates uncontrolled hyperglycemia.
    """
    return guidelines

# --- AGENT EXECUTION CORE ---

def run_triage_agent(patient_id: str):
    print(f"\n=======================================================")
    print(f"ACTUATING REMOTE PATIENT TRIAGE AGENT FOR: {patient_id}")
    print(f"=======================================================")

    # 1. Execute tools to build complete analytical context
    print("[Agent Workflow] Executing Tool 1: Fetching Clinical EMR Baseline...")
    emr_context = tool_get_clinical_baseline(patient_id)

    print("[Agent Workflow] Executing Tool 2: Fetching Connected Device Streams...")
    telemetry_context = tool_get_remote_telemetry(patient_id)

    print("[Agent Workflow] Executing Tool 3: Querying Clinical Knowledge Base (RAG)...")
    rag_guidelines = tool_clinical_knowledge_rag()

    # 2. System Instruction for Agent Reasoning & Guardrails
    system_instruction = """
    You are an advanced Clinical Triage Agent specializing in Remote Patient Monitoring (RPM). 
    Your objective is to analyze a patient's historical EMR context alongside their recent home sensor data, cross-reference them with standard medical guidelines, and determine if an emergency alert must be sent to their healthcare provider.
    
    CRITICAL INSTRUCTIONS:
    - Review the baseline instructions written in the EMR note's 'PLAN' section.
    - Evaluate each telemetry data point sequentially by timestamp.
    - If a reading violates BOTH standard clinical knowledge AND the patient's specific customized plan, flag it immediately as a 'CRITICAL BREAK'.
    
    Output your final analysis strictly in JSON format with the following keys:
    - "patient_id": The evaluated patient string.
    - "clinical_status": "STABLE", "MONITOR", or "CRITICAL_ALERT".
    - "detected_anomalies": An array of strings explaining what readings went out of bounds and when.
    - "provider_action_required": Boolean true/false.
    - "justification": A clear, professional summary of why you made this clinical triage choice.
    """

    # Assemble payload for the LLM
    user_content = f"""
    === TOOL OUTPUT 1: PATIENT BASELINE EMR ===
    {emr_context}
    
    === TOOL OUTPUT 2: HOME DEVICE TELEMETRY LOGS ===
    {json.dumps(telemetry_context, indent=2)}
    
    === TOOL OUTPUT 3: MEDICAL RAG REFERENCE RANGE ===
    {rag_guidelines}
    """

    try:
        # Call Gemini 2.5 Flash as our reasoning engine
        response = client.models.generate_content(
            model=MODEL_ID,
            contents=user_content,
            config=types.GenerateContentConfig(
                system_instruction=system_instruction,
                response_mime_type="application/json",
                temperature=0.1 # Low temperature for strict, clinical reasoning accuracy
            )
        )
        
        # Output the Agent's decision
        agent_decision = json.loads(response.text)
        print("\n[Agent Decision Received Summary]:")
        print(json.dumps(agent_decision, indent=2))
        
    except Exception as e:
        print(f"Agent Execution Failure: {e}")

if __name__ == "__main__":
    # Test your working agent against the patient we just saw in your output window
    run_triage_agent("PID-36949")
