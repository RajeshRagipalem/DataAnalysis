import streamlit as st
import pandas as pd
import json
import os
from datetime import datetime, timezone
from google.cloud import bigquery, storage
from google.api_core.exceptions import NotFound
from google import genai
from google.genai import types

# --- CONFIGURATION ---
PROJECT_ID = "avid-willow-485619-g6"
LOCATION = "us-central1"
BUCKET_NAME = f"healthcare-agent-data-{PROJECT_ID}"
DATASET_ID = "healthcare_agent_db"
DATASET_REF = f"{PROJECT_ID}.{DATASET_ID}"
EMR_TABLE = f"{DATASET_REF}.patient_emr_baselines"
TELEMETRY_TABLE = f"{DATASET_REF}.patient_telemetry"
MODEL_ID = "gemini-2.5-flash"

# Initialize GCP Clients
bq_client = bigquery.Client(project=PROJECT_ID)
storage_client = storage.Client(project=PROJECT_ID)
ai_client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)

st.set_page_config(page_title="RPM Triage Agent", layout="wide")
st.title("🏥 Remote Patient Monitoring & AI Triage")

# ==========================================
# ZERO-TOUCH ADMIN FUNCTIONS (BACKEND LOGIC)
# ==========================================

def setup_telemetry_db():
    dataset = bigquery.Dataset(DATASET_REF)
    dataset.location = "US"
    try:
        bq_client.create_dataset(dataset, exists_ok=True)
    except Exception:
        pass

    schema = [
        bigquery.SchemaField("patient_id", "STRING"),
        bigquery.SchemaField("timestamp", "TIMESTAMP"),
        bigquery.SchemaField("blood_pressure", "STRING"),
        bigquery.SchemaField("systolic_bp", "INTEGER"),
        bigquery.SchemaField("diastolic_bp", "INTEGER"),
        bigquery.SchemaField("spo2_percent", "INTEGER"),
        bigquery.SchemaField("blood_glucose_mg_dl", "INTEGER"),
        bigquery.SchemaField("weight_lbs", "INTEGER"),
    ]
    
    table = bigquery.Table(TELEMETRY_TABLE, schema=schema)
    bq_client.create_table(table, exists_ok=True)

    rows_to_insert = []
    source_dir = "data/telemetry_structured"
    for filename in os.listdir(source_dir):
        if filename.endswith(".json"):
            with open(os.path.join(source_dir, filename), "r") as f:
                data = json.load(f)
                for record in data:
                    rows_to_insert.append({
                        "patient_id": record["patient_id"],
                        "timestamp": record["timestamp"],
                        "blood_pressure": record["sensor_readings"]["blood_pressure"],
                        "systolic_bp": record["sensor_readings"]["systolic_bp"],
                        "diastolic_bp": record["sensor_readings"]["diastolic_bp"],
                        "spo2_percent": record["sensor_readings"]["spo2_percent"],
                        "blood_glucose_mg_dl": record["sensor_readings"]["blood_glucose_mg_dl"],
                        "weight_lbs": record["sensor_readings"]["weight_lbs"]
                    })
    
    if rows_to_insert:
        bq_client.insert_rows_json(TELEMETRY_TABLE, rows_to_insert)
        return len(rows_to_insert)
    return 0

def extract_and_summarize_emrs():
    dataset = bigquery.Dataset(DATASET_REF)
    dataset.location = "US"
    bq_client.create_dataset(dataset, exists_ok=True)
    
    schema = [
        bigquery.SchemaField("patient_id", "STRING"),
        bigquery.SchemaField("summary", "STRING"),
        bigquery.SchemaField("extracted_entities", "STRING")
    ]
    
    table = bigquery.Table(EMR_TABLE, schema=schema)
    bq_client.create_table(table, exists_ok=True)

    bucket = storage_client.bucket(BUCKET_NAME)
    blobs = bucket.list_blobs(prefix="emr_unstructured/")
    
    prompt = """
    Analyze the patient EMR document and extract the information into strict JSON format:
    1. "extracted_entities": Patient ID, Name, Age, Condition, Medication, and Baseline Vitals.
    2. "summary": A concise, 2-sentence summary of the patient's status and medical plan.
    """
    
    rows_to_insert = []
    processed_count = 0
    for blob in blobs:
        if not blob.name.endswith('.txt'): continue
        gcs_uri = f"gs://{BUCKET_NAME}/{blob.name}"
        
        response = ai_client.models.generate_content(
            model=MODEL_ID,
            contents=[types.Part.from_uri(file_uri=gcs_uri, mime_type="text/plain"), prompt],
            config=types.GenerateContentConfig(response_mime_type="application/json")
        )
        parsed_json = json.loads(response.text)
        patient_id = parsed_json["extracted_entities"].get("Patient ID", "UNKNOWN")
        
        rows_to_insert.append({
            "patient_id": patient_id,
            "summary": parsed_json["summary"],
            "extracted_entities": json.dumps(parsed_json["extracted_entities"])
        })
        processed_count += 1

    if rows_to_insert:
        bq_client.insert_rows_json(EMR_TABLE, rows_to_insert)
    return processed_count

def inject_live_telemetry(patient_id, sys, dia, spo2, gluc, weight):
    """Simulates a live IoT sensor pushing a new reading to BigQuery."""
    current_time = datetime.now(timezone.utc).isoformat()
    row = [{
        "patient_id": patient_id,
        "timestamp": current_time,
        "blood_pressure": f"{sys}/{dia}",
        "systolic_bp": sys,
        "diastolic_bp": dia,
        "spo2_percent": spo2,
        "blood_glucose_mg_dl": gluc,
        "weight_lbs": weight
    }]
    errors = bq_client.insert_rows_json(TELEMETRY_TABLE, row)
    return errors

# ==========================================
# AGENT LOGIC & DATA RETRIEVAL
# ==========================================

def get_emr(patient_id):
    query = f"SELECT summary, extracted_entities FROM `{EMR_TABLE}` WHERE patient_id = '{patient_id}' LIMIT 1"
    try:
        df = bq_client.query(query).to_dataframe()
        if not df.empty:
            summary = df.iloc[0]["summary"]
            entities = json.loads(df.iloc[0]["extracted_entities"])
            formatted_text = f"**CLINICAL SUMMARY:**\n{summary}\n\n**EXTRACTED BASELINE:**\n"
            for key, value in entities.items():
                formatted_text += f"- **{key}**: {value}\n"
            return formatted_text
        return "⚠️ EMR Baseline Not Found. Run Extraction."
    except NotFound:
        return "⚠️ BigQuery Table Not Found. Please initialize the database in Admin Controls."

def get_telemetry(patient_id):
    query = f"SELECT timestamp, systolic_bp, diastolic_bp, spo2_percent, blood_glucose_mg_dl FROM `{TELEMETRY_TABLE}` WHERE patient_id = '{patient_id}' ORDER BY timestamp ASC"
    try:
        return bq_client.query(query).to_dataframe()
    except NotFound:
        return pd.DataFrame()

def run_triage_agent(patient_id, emr_text, telemetry_df):
    system_instruction = """
    You are a Clinical Triage Agent. Analyze the patient's EMR baseline and their recent telemetry data.
    Cross-reference with medical standards (e.g., SpO2 < 92% is dangerous, Systolic > 140 is hypertensive).
    Output valid JSON:
    {
      "clinical_status": "STABLE" or "CRITICAL_ALERT",
      "detected_anomalies": ["list of issues"],
      "justification": "Why you made this decision"
    }
    """
    telemetry_json = telemetry_df.to_json(orient="records", date_format="iso")
    user_content = f"=== EMR ===\n{emr_text}\n=== TELEMETRY ===\n{telemetry_json}"
    
    response = ai_client.models.generate_content(
        model=MODEL_ID,
        contents=user_content,
        config=types.GenerateContentConfig(
            system_instruction=system_instruction,
            response_mime_type="application/json",
            temperature=0.1
        )
    )
    return json.loads(response.text)

# ==========================================
# UI LAYOUT
# ==========================================

with st.sidebar:
    st.header("⚙️ Admin Controls")
    st.write("Initialize cloud resources before testing.")
    
    if st.button("1. Load Telemetry to BigQuery", use_container_width=True):
        with st.spinner("Creating BQ Dataset and loading JSONs..."):
            count = setup_telemetry_db()
            st.success(f"Loaded {count} rows!")
            
    if st.button("2. Extract EMRs via Vertex AI", use_container_width=True):
        with st.spinner("Running Gemini batch extraction..."):
            count = extract_and_summarize_emrs()
            st.success(f"Processed {count} EMRs!")
            
    st.divider()
    st.header("🔍 Select Patient")
    patient_id = st.selectbox("Patient ID", ["PID-36949", "PID-40992", "PID-42299", "PID-50953", "PID-91465"])

col1, col2 = st.columns([1, 1])

with col1:
    st.subheader("📄 Clinical Baseline (BigQuery via Vertex AI)")
    emr_data = get_emr(patient_id)
    st.markdown(emr_data)

with col2:
    st.subheader("📈 Telemetry Stream (BigQuery)")
    df = get_telemetry(patient_id)
    if not df.empty:
        st.dataframe(df, use_container_width=True, height=200)
        st.line_chart(df, x="timestamp", y=["systolic_bp", "spo2_percent"], height=200)
    else:
        st.warning("No telemetry data found. Click 'Load Telemetry to BigQuery' in the sidebar.")

st.divider()

# --- DEMO DATA INJECTION ---
st.subheader("🧪 Demo: Inject Live Telemetry Anomaly")
with st.expander("Manually add a new IoT sensor reading to BigQuery", expanded=False):
    c1, c2, c3, c4, c5 = st.columns(5)
    sys = c1.number_input("Systolic BP", min_value=50, max_value=250, value=120)
    dia = c2.number_input("Diastolic BP", min_value=30, max_value=150, value=80)
    spo2 = c3.number_input("SpO2 %", min_value=50, max_value=100, value=98)
    gluc = c4.number_input("Glucose", min_value=40, max_value=500, value=100)
    weight = c5.number_input("Weight", min_value=50, max_value=500, value=180)
    
    if st.button("Inject Data & Refresh Charts", type="secondary"):
        errors = inject_live_telemetry(patient_id, sys, dia, spo2, gluc, weight)
        if not errors:
            st.success("New reading successfully pushed to BigQuery!")
            st.rerun()  # Instantly refreshes the UI so the new data point appears on the graph
        else:
            st.error(f"Failed to inject: {errors}")

st.divider()

# --- RUN TRIAGE ---
st.subheader("🤖 Run Agentic Triage Workflow")
if st.button(f"Analyze Patient {patient_id}", type="primary"):
    if df.empty or "⚠️" in emr_data:
        st.error("Please initialize the databases using the Admin Controls first.")
    else:
        with st.spinner("Agent is analyzing BigQuery telemetry against EMR context..."):
            try:
                result = run_triage_agent(patient_id, emr_data, df)
                if result.get("clinical_status") == "CRITICAL_ALERT":
                    st.error("🚨 **CRITICAL ALERT INITIATED**")
                else:
                    st.success("✅ **PATIENT STABLE**")
                st.json(result)
            except Exception as e:
                st.error(f"Agent Error: {e}")
