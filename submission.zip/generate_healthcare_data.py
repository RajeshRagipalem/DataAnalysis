import os
import json
import random
from datetime import datetime, timedelta
from faker import Faker

fake = Faker()

# Create directories to simulate GCP landing zones
EMR_DIR = "data/emr_unstructured"
TELEMETRY_DIR = "data/telemetry_structured"
os.makedirs(EMR_DIR, exist_ok=True)
os.makedirs(TELEMETRY_DIR, exist_ok=True)

# Medical vocabularies for realistic text generation
CONDITIONS = ["Type 2 Diabetes", "Hypertension", "COPD", "Congestive Heart Failure", "Asthma"]
MEDICATIONS = ["Metformin 500mg", "Lisinopril 10mg", "Albuterol Inhaler", "Furosemide 20mg", "Amlodipine 5mg"]

def generate_emr_note(patient_id, name, age, condition, medication):
    """Generates an unstructured text document representing a doctor's clinical note."""
    date_of_visit = fake.date_between(start_date='-1y', end_date='today').strftime('%Y-%m-%d')
    
    note = f"CLINICAL ENCOUNTER NOTE\n"
    note += f"Date: {date_of_visit}\n"
    note += f"Patient ID: {patient_id}\n"
    note += f"Patient Name: {name}\n"
    note += f"Age: {age} years old\n\n"
    
    note += f"CHIEF COMPLAINT & HISTORY:\n"
    note += f"Patient presents today for a routine follow-up regarding their {condition}. "
    note += f"They report feeling generally {random.choice(['well', 'fatigued', 'short of breath lately', 'stable'])}. "
    note += f"Patient compliance with {medication} is reported as {random.choice(['good', 'sporadic', 'excellent'])}.\n\n"
    
    note += f"BASELINE VITALS AT CLINIC:\n"
    note += f"BP: {random.randint(110, 140)}/{random.randint(70, 90)} mmHg\n"
    note += f"HR: {random.randint(60, 90)} bpm\n"
    note += f"SpO2: {random.randint(94, 99)}% on room air\n"
    note += f"Weight: {random.randint(150, 250)} lbs\n\n"
    
    note += f"PLAN:\n"
    note += f"1. Continue current dosage of {medication}.\n"
    note += f"2. Patient enrolled in Remote Patient Monitoring (RPM) program.\n"
    note += f"3. Monitor daily vitals. Alert provider if SpO2 drops below 92% or Systolic BP exceeds 150.\n"
    
    return note

def generate_telemetry(patient_id, condition, days_back=7):
    """Generates a list of structured JSON payloads representing daily IoT sensor readings."""
    telemetry_logs = []
    base_date = datetime.now() - timedelta(days=days_back)
    
    for day in range(days_back):
        current_date = base_date + timedelta(days=day)
        
        # Introduce occasional anomalies based on condition to test the RAG/Triage Agent
        is_anomalous = random.random() < 0.2  # 20% chance of a bad reading
        
        if condition == "COPD" and is_anomalous:
            spo2 = random.randint(85, 90) # Dangerously low O2
        else:
            spo2 = random.randint(94, 100)
            
        if condition == "Hypertension" and is_anomalous:
            systolic = random.randint(160, 180) # Hypertensive crisis
            diastolic = random.randint(95, 110)
        else:
            systolic = random.randint(115, 135)
            diastolic = random.randint(75, 85)
            
        if condition == "Type 2 Diabetes" and is_anomalous:
            glucose = random.randint(200, 300) # High blood sugar
        else:
            glucose = random.randint(90, 130)

        log = {
            "timestamp": current_date.isoformat(),
            "patient_id": patient_id,
            "sensor_readings": {
                "blood_pressure": f"{systolic}/{diastolic}",
                "systolic_bp": systolic,
                "diastolic_bp": diastolic,
                "spo2_percent": spo2,
                "blood_glucose_mg_dl": glucose,
                "weight_lbs": random.randint(180, 185) # Weight stays relatively static
            },
            "device_status": "ONLINE",
            "battery_level": random.randint(40, 100)
        }
        telemetry_logs.append(log)
    return telemetry_logs

def main():
    NUM_PATIENTS = 5 # Small prototype batch
    
    print(f"Generating synthetic healthcare data for {NUM_PATIENTS} patients...")
    
    for _ in range(NUM_PATIENTS):
        patient_id = f"PID-{random.randint(10000, 99999)}"
        name = fake.name()
        age = random.randint(45, 85)
        condition = random.choice(CONDITIONS)
        medication = random.choice(MEDICATIONS)
        
        # 1. Generate and save unstructured EMR
        emr_text = generate_emr_note(patient_id, name, age, condition, medication)
        emr_filename = os.path.join(EMR_DIR, f"{patient_id}_emr.txt")
        with open(emr_filename, "w") as f:
            f.write(emr_text)
            
        # 2. Generate and save structured Telemetry
        telemetry_data = generate_telemetry(patient_id, condition)
        telemetry_filename = os.path.join(TELEMETRY_DIR, f"{patient_id}_telemetry.json")
        with open(telemetry_filename, "w") as f:
            json.dump(telemetry_data, f, indent=4)
            
    print(f"Data generation complete!")
    print(f"Unstructured EMRs saved to: {EMR_DIR}/")
    print(f"Structured Telemetry saved to: {TELEMETRY_DIR}/")

if __name__ == "__main__":
    main()
