# 🏥 Remote Patient Monitoring (RPM) & AI Triage Workflow on GCP

This repository contains a fully functional, GCP-native prototype for an **Intelligent Remote Patient Monitoring (RPM) & Triage Agentic System**. The solution processes unstructured Electronic Medical Records (EMRs), stores structured telemetry configurations in a cloud data warehouse, and leverages **Gemini 2.5 Flash** via the unified `google-genai` SDK to evaluate real-time biometric telemetry alerts for at-home patients.

---

## 📂 Project Structure

```text
├── app.py                           # Unified Streamlit Clinical UI Dashboard (with Admin Controls)
├── generate_healthcare_data.py      # Python script to generate synthetic EMR text and IoT JSON files
├── upload_to_gcp.py                 # Ingestion script to create a GCS bucket and stage raw datasets
├── extract_and_summarize.py         # Batch extraction module (stages structured EMR notes to BigQuery)
├── load_to_bq.py                    # Structured telemetry loader module for BigQuery
├── triage_agent.py                  # Standalone Agentic Triage script demonstrating tool execution
├── requirements.txt                 # Frozen Python environment dependencies
├── Architecture & Agent Design Report.md # Core technical architecture documentation
└── data/                            # Local sandbox landing zone for generated text/JSON structures
    ├── emr_unstructured/            # Synthetic clinical notes (.txt)
    └── telemetry_structured/        # Synthetic IoT device telemetry streams (.json)
```

---

## 🛠️ Prerequisites & GCP Resource Requirements

[cite_start]To deploy and execute this prototype, ensure you have an active Google Cloud Platform account with a project configured for billing.

### 1. Enabled Cloud APIs
Your GCP project must have the following APIs activated:
* **Vertex AI API** (`aiplatform.googleapis.com`)
* **BigQuery API** (`bigquery.googleapis.com`)
* **Cloud Storage API** (`storage.googleapis.com`)

### 2. Required Local Tooling
* Python **3.10+**
* Google Cloud CLI (`gcloud`) initialized and linked to your target environment.

### 3. Crucial IAM Service Agent Permissions
When sending Google Cloud Storage (GCS) `gs://` object URIs directly into Vertex AI multimodal API endpoints, the Vertex AI internal service engine evaluates the objects using its own backend Service Agent. You must explicitly grant permissions to avoid `403 Access Denied` exceptions:
```bash
gcloud storage buckets add-iam-policy-binding gs://YOUR_CREATABLE_BUCKET_NAME \
  --member="serviceAccount:service-YOUR_PROJECT_NUMBER@gcp-sa-aiplatform.iam.gserviceaccount.com" \
  --role="roles/storage.objectViewer"
```

---

## 💾 Dataset Source & Ingestion

All files utilized in this prototype are deterministically simulated to replicate modern IoT medical peripherals (e.g., Omron blood pressure cuffs, Hospira pulse oximeters) and legacy medical software:
* **Unstructured Source:** Local text files containing clinical follow-up summaries, baseline metrics, and condition-specific warning configurations (e.g., "Alert provider if SpO2 drops below 92%").
* **Structured Source:** Relational time-series JSON arrays tracking metrics sequentially (systolic/diastolic blood pressure, oxygen saturation levels, weight, and blood glucose values).

---

## 🚀 Step-by-Step Setup & Execution

Follow these instructions to spin up the zero-touch clinical ecosystem:

### 1. Environment Activation & Dependencies
Clone or navigate to the project root directory, activate your virtual environment, and install the required modules:
```bash
# Create and activate environment
python3 -m venv venv
source venv/bin/activate

# Install frozen dependencies
pip install -r requirements.txt
```

### 2. Authenticate Your Local Machine to GCP
Log into your Google Cloud account through your terminal and establish your project quota definitions:
```bash
gcloud auth application-default login
gcloud auth application-default set-quota-project YOUR_GCP_PROJECT_ID
```

### 3. Generate the Synthetic Dataset
Run the python data pipeline to populate your local `data/` directories with realistic patient telemetry and medical history records:
```bash
python generate_healthcare_data.py
```

### 4. Stage Datasets onto Google Cloud Storage
Configure the `PROJECT_ID` parameter inside `upload_to_gcp.py` to match your environment, then execute it to create your storage bucket and upload all raw text and JSON files:
```bash
python upload_to_gcp.py
```

### 5. Launch the Zero-Touch Streamlit App
Launch the main user dashboard web interface directly from your virtual environment:
```bash
streamlit run app.py
```

---

## 🏥 Testing the Clinical UI Dashboard Demo

Once the Streamlit interface opens in your local browser window:
1.  **Initialize the Environment:** In the left sidebar under **Admin Controls**, click `1. Load Telemetry to BigQuery` followed by `2. Extract EMRs via Vertex AI`. This automatically provisions your BigQuery datasets, defines your layout structures, and runs a batch extraction process converting unstructured raw clinical text into clean relational schemas.
2.  **Evaluate a Baseline:** Select any Patient ID from the drop-down menu (e.g., `PID-36949`) and hit `Analyze Patient`. The agent will query your newly initialized structured records and confirm the patient is **STABLE**.
3.  **Inject a Real-Time Anomaly:** Open the **Demo: Inject Live Telemetry Anomaly** expander. Select the active patient, manually alter their `SpO2 %` down to an unsafe level (e.g., `85%`), and click `Inject Data & Refresh Charts`.
4.  **Confirm Agent Logic:** You will immediately see the time-series line chart dip on the dashboard. Click `Analyze Patient` a second time. The Gemini reasoning engine will parse the updated data warehouse stream, notice the metric violation against the patient's individual treatment plan, and flag a striking red **CRITICAL ALERT** complete with clinical justification.
