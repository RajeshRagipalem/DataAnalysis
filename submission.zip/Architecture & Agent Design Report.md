# Architecture & Agent Design Report
## Remote Patient Monitoring (RPM) & AI Triage Prototype

**Role:** Lead AI/ML Engineer
**Focus:** Intelligent Data Extraction & Agentic Workflows on GCP

---

### 1. Overview & Scenario
This prototype demonstrates a **"Remote Patient Monitoring (RPM) & Triage Agent"**, designed to automate the clinical assessment of at-home patients. 

**The Business Problem:** Healthcare providers are overwhelmed by continuous streams of IoT telemetry data (blood pressure, SpO2, glucose) from at-home medical devices. Identifying actionable anomalies requires cross-referencing this live data with a patient’s historical electronic medical record (EMR).
**The AI Solution:** A GCP-native agentic workflow that digests unstructured clinical notes, structures the baseline context, and autonomously evaluates incoming telemetry streams against both patient-specific care plans and standard medical RAG guidelines to trigger critical alerts.

### 2. Technical Approach & GCP Services Used
The architecture strictly leverages Google Cloud Platform native managed services to ensure scalability, security, and low-latency inference:
* **Google Cloud Storage (GCS):** Acts as the landing zone for raw, unstructured EMR text files.
* **BigQuery:** Serves as the central Data Warehouse. It stores the structured telemetry streams and the parsed, structured EMR baseline outputs, allowing the agent to utilize lightning-fast SQL lookups rather than repeatedly parsing raw text.
* **Vertex AI (Gemini 2.5 Flash):** Powered by the modern `google-genai` SDK, Gemini acts as both the **Information Extractor** (converting unstructured EMRs to strict JSON) and the **Reasoning Engine** (evaluating clinical anomalies). Flash was selected for its cost-effectiveness and high-speed multimodal reasoning.
* **Streamlit:** Provides the interactive Clinical Provider Dashboard, featuring zero-touch cloud initialization and live IoT anomaly injection for demonstration purposes.

### 3. Agentic Workflow & Reasoning Architecture
While third-party orchestration frameworks like LangChain were considered, this prototype intentionally utilizes a **pure GCP-native routing architecture**. By leveraging Gemini's native `system_instruction` capabilities to evaluate outputs from modular Python functions, we eliminate framework overhead, reduce execution latency, and maintain strict alignment with enterprise GCP deployment patterns.

**The Agent's Toolchain:**
1.  **Clinical Historian (`get_emr`):** A BigQuery lookup tool that retrieves the patient's pre-extracted baseline entities and medical plan.
2.  **Telemetry Monitor (`get_telemetry`):** A BigQuery retrieval tool that fetches the time-series IoT sensor data for the patient.
3.  **Clinical Knowledge Base (RAG Rules):** Enforced via the system prompt, providing the agent with hard biomedical boundaries (e.g., "SpO2 < 92% is dangerous").

**Execution Flow:**
The Supervisor Agent retrieves context from Tools 1 and 2, evaluates the chronological sensor data against Tool 3 and the patient's specific care plan, and outputs a deterministic JSON payload classifying the patient as `STABLE` or `CRITICAL_ALERT`, complete with clinical justification.

### 4. High-Level GCP Architecture Diagram

```mermaid
graph TD
    %% Define Nodes
    subgraph Data Ingestion
        A[Unstructured EMR Docs] -->|Uploaded via SDK| B(Cloud Storage)
        C[Raw IoT Telemetry JSON] -->|Batch Load| D(BigQuery Telemetry Table)
    end

    subgraph Information Extraction & Structuring
        B -->|Part.from_uri| E{Vertex AI: Gemini 2.5 Flash}
        E -->|Strict JSON Entities & Summary| F(BigQuery EMR Table)
    end

    subgraph Agentic Triage Workflow
        F -->|Tool: get_emr| G[Triage Agent / Streamlit UI]
        D -->|Tool: get_telemetry| G
        H[(Clinical RAG Guidelines)] -.->|System Prompt| G
        G -->|Reasoning Context| I{Vertex AI: Gemini 2.5 Flash}
    end

    subgraph Output
        I -->|JSON Response| J((Clinical Dashboard Alert))
    end
    
    %% Styling
    classDef gcp fill:#e8f0fe,stroke:#1a73e8,stroke-width:2px;
    classDef agent fill:#fef7e0,stroke:#f29900,stroke-width:2px;
    class B,D,F,I,E gcp;
    class G agent;
```

### 5. Results, Challenges & Trade-offs
* **Result:** The agent successfully extracted high-cardinality clinical data into deterministic JSON arrays and accurately identified synthetic anomalies (e.g., sudden SpO2 drops), triggering alerts without hallucinating out-of-bounds metrics.
* **Challenge - IAM Service Agent Permissions:** Passing GCS `gs://` URIs directly to Vertex AI initially resulted in 403 Forbidden errors. This was resolved by explicitly granting the `service-...@gcp-sa-aiplatform.iam.gserviceaccount.com` service agent the `Storage Object Viewer` role.
* **Trade-off - Latency vs. Freshness:** To optimize inference speed and API costs, EMR parsing was decoupled from the live Triage Agent. EMRs are batch-processed into BigQuery, meaning the agent reads structured data instantly. The trade-off is that an EMR update requires a batch re-run to update the agent's memory.

### 6. Productionization Approach
To extend this prototype into a highly available, enterprise-grade real-world deployment, the following architecture would be implemented:

* **Scalability & Orchestration (Event-Driven):** Instead of polling BigQuery, the system will use **Cloud Pub/Sub**. IoT devices will stream payloads to a Pub/Sub topic. This topic will simultaneously sink to BigQuery for historical storage and trigger a **Cloud Run** container housing the Triage Agent. The agent evaluates the payload in milliseconds and publishes critical alerts to a separate high-priority topic. EMR extraction workflows will be orchestrated via **Cloud Composer (Airflow)** or **Vertex AI Pipelines**.
* **Security & Data Privacy (HIPAA Compliance):**
    All data at rest will use CMEK (Customer-Managed Encryption Keys). **Cloud Data Loss Prevention (DLP)** will be utilized to de-identify/mask Protected Health Information (PHI) before it enters analytical pipelines. IAM will enforce strict least-privilege access.
* **Monitoring & Cost Optimization:**
    **Vertex AI Model Monitoring** will be deployed to track reasoning drift or hallucination rates. Costs are optimized by restricting the LLM to event-driven invocations rather than continuous polling loops, and utilizing `gemini-2.5-flash` for high-throughput, low-latency evaluation tasks.
* **CI/CD:**
    Infrastructure will be managed via **Terraform**. **Cloud Build** will execute automated integration tests (e.g., injecting known telemetry anomalies to assert the agent outputs `CRITICAL_ALERT` 100% of the time) before deploying the agent container to Cloud Run.
