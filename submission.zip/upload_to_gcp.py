import os
from google.cloud import storage

# --- CONFIGURATION ---
# Replace with your actual GCP Project ID
PROJECT_ID = "avid-willow-485619-g6" 
# GCS bucket names must be globally unique, so add some random numbers at the end
BUCKET_NAME = f"healthcare-agent-data-{PROJECT_ID}" 

def upload_directory_to_gcs(bucket_name, source_directory, destination_blob_prefix):
    """Uploads a local directory to a GCS bucket."""
    storage_client = storage.Client(project=PROJECT_ID)
    
    # Create the bucket if it doesn't exist
    try:
        bucket = storage_client.get_bucket(bucket_name)
        print(f"Bucket {bucket_name} already exists.")
    except Exception:
        print(f"Creating bucket {bucket_name}...")
        bucket = storage_client.create_bucket(bucket_name, location="US")

    # Walk through the local directory and upload files
    for root, dirs, files in os.walk(source_directory):
        for file in files:
            local_path = os.path.join(root, file)
            # Construct the GCS path (e.g., emr_unstructured/PID-12345_emr.txt)
            blob_path = f"{destination_blob_prefix}/{file}"
            
            blob = bucket.blob(blob_path)
            blob.upload_from_filename(local_path)
            print(f"Uploaded {file} to gs://{bucket_name}/{blob_path}")

def main():
    print("Starting data ingestion to Google Cloud Storage...")
    
    # Upload Unstructured EMRs
    upload_directory_to_gcs(
        bucket_name=BUCKET_NAME,
        source_directory="data/emr_unstructured",
        destination_blob_prefix="emr_unstructured"
    )
    
    # Upload Structured Telemetry
    upload_directory_to_gcs(
        bucket_name=BUCKET_NAME,
        source_directory="data/telemetry_structured",
        destination_blob_prefix="telemetry_structured"
    )
    
    print("Data ingestion complete! Your foundation is ready for Vertex AI.")

if __name__ == "__main__":
    main()
